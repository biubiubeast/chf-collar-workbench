'use client';
import {useMemo,useState} from 'react';
import type {DisplayConfig} from '@/lib/display-config';
import type {Config} from '@/lib/finance';
import {days} from '@/lib/finance';
import {strategy,type Leg,type Market,type StrategyResult} from '@/lib/strategy';
import {rebuildPresentationScenario,presentationScenarioDetails,spotFromCHFChange,type PresentationFundingInput} from '@/lib/presentation-scenario';
import {Metric,Table,money,number,percent} from './lab-ui';
import PresentationChart from './presentation-chart';
import PresentationGuide from './presentation-guide';
import OptionGreeksPanel from './option-greeks-panel';
import {buildPresentationVenue,rebuildPresentationFunding} from '@/lib/presentation-venues';
import PresentationExport from './presentation-export';
import {FormulaButton} from './presentation-formula-dialog';
import type {Overrides} from '@/lib/formulas';

type PublishedScenario=NonNullable<DisplayConfig['scenario']>;
type Props={config:DisplayConfig;variant:'presentation'|'workbench';adminPreview?:boolean};
const active=(l:Leg)=>l.enabled&&l.notional>0;
const isLow=(l:Leg,mode:Config['mode'])=>active(l)&&l.type==='put'&&l.side===(mode==='loan'?'sell':'buy');
const isHigh=(l:Leg,mode:Config['mode'])=>active(l)&&l.type==='call'&&l.side===(mode==='loan'?'buy':'sell');
const sameStrike=(legs:Leg[],fallback:number)=>legs.length&&legs.every(l=>Math.abs(l.strike-legs[0].strike)<1e-8)?legs[0].strike:fallback;
const boundText=(r:StrategyResult,side:'min'|'max')=>r.bound?money(r.bound[side]):'暂不可计算';

/** Server-published snapshot, locally explored. Never reads or writes admin browser state. */
export default function ClientPresentation({config,variant,adminPreview=false}:Props){
 const scenarioKey=useMemo(()=>{let hash=2166136261;const text=JSON.stringify(config.scenario);for(let i=0;i<text.length;i++)hash=Math.imul(hash^text.charCodeAt(i),16777619);return`${config.updatedAt}-${hash>>>0}-${variant}`;},[config.scenario,config.updatedAt,variant]);
 if(!config.controls.otc&&!config.controls.cme)return <main className="workspace presentation-workspace"><p className="warning">请在展示管理中至少开启 OTC 或 CME 一种交易方式。</p></main>;
 if(!config.scenario)return <main className="workspace presentation-workspace"><section className="panel presentation-empty"><div className="eyebrow">CHF COLLAR · 客户演示</div><h1>管理员尚未发布展示方案</h1><p>发布后，这里将展示已确认的策略、收益曲线和可调整的演示参数。</p>{adminPreview&&<a className="text-button" href="/display">前往展示管理发布方案</a>}</section></main>;
 return <PublishedClient key={scenarioKey} config={config} snapshot={config.scenario} variant={variant} adminPreview={adminPreview}/>;
}

function PublishedClient({config,snapshot,variant,adminPreview}:{config:DisplayConfig;snapshot:PublishedScenario;variant:Props['variant'];adminPreview:boolean}){
 const section=config.sections,base=snapshot.c;
 const allowedVenues=(['OTC','CME'] as const).filter(v=>v==='OTC'?config.controls.otc:config.controls.cme),venueKey=allowedVenues.join(',');
 const originalVenue=snapshot.legs.filter(active).every(l=>l.venue==='CME')&&snapshot.legs.some(active)?'CME':'OTC';
 const initialVenue=allowedVenues.includes(originalVenue)?originalVenue:allowedVenues[0];
 const [chosenVenue,setChosenVenue]=useState<'OTC'|'CME'>(initialVenue),[cmePolicy,setCmePolicy]=useState<'before-roll'|'after-close'>(base.cmeExpiry?.mode==='before-roll'?'before-roll':'after-close');
 const venue=allowedVenues.includes(chosenVenue)?chosenVenue:allowedVenues[0];
 const lowLegs=snapshot.legs.filter(l=>isLow(l,base.mode)),highLegs=snapshot.legs.filter(l=>isHigh(l,base.mode));
 const initialLow=sameStrike(lowLegs,base.low),initialHigh=sameStrike(highLegs,base.high);
 const [low,setLow]=useState(initialLow),[high,setHigh]=useState(initialHigh),[lowEdited,setLowEdited]=useState(false),[highEdited,setHighEdited]=useState(false);
 const initialLegIVs=()=>Object.fromEntries(snapshot.legs.map(l=>[l.id,l.modelIV??(l.type==='call'?.08:.085)]));
 const [iv,setIv]=useState(base.iv),[ivMode,setIvMode]=useState<'reference'|'uniform'|'per-leg'>('per-leg'),[legIVs,setLegIVs]=useState<Record<string,number>>(initialLegIVs);
 const [premiumFunding,setPremiumFunding]=useState<NonNullable<Config['premiumFunding']>>(base.premiumFunding??'internal');
 const [funding,setFunding]=useState<PresentationFundingInput>({equity:base.equity,start:base.start,durationDays:days(base.start,base.end),sizing:'proportional'});
 const [rebuilt,setRebuilt]=useState<ReturnType<typeof rebuildPresentationScenario>|null>(null),[fundingError,setFundingError]=useState('');
 const current=rebuilt?.c??base,currentLegs=rebuilt?.legs??snapshot.legs,currentMarket=rebuilt?.market??snapshot.market;
 const fundingPending=funding.equity!==current.equity||funding.start!==current.start||funding.durationDays!==days(current.start,current.end);
 const [cases,setCases]=useState([{id:'down',name:'瑞郎贬值 10%',changePct:-10},{id:'flat',name:'瑞郎汇率不变',changePct:0},{id:'up',name:'瑞郎升值 10%',changePct:10}]),[selectedCase,setSelectedCase]=useState('flat');
 const [newChange,setNewChange]=useState('20'),[newName,setNewName]=useState(''),[caseError,setCaseError]=useState('');
 const selected=cases.find(x=>x.id===selectedCase)??cases[0],spot=spotFromCHFChange(base.spot,selected.changePct);
 const setSpot=(s:number)=>{if(!(s>0&&Number.isFinite(s)))return;try{const changePct=(s/base.spot-1)*100;spotFromCHFChange(base.spot,changePct);setCases(v=>v.map(x=>x.id===selected.id?{...x,changePct}:x));setCaseError('');}catch(e){setCaseError(e instanceof Error?e.message:'情景超出支持范围');}};
 const [stressSpot,setStressSpot]=useState(base.spot*1.2),[resetKey,setResetKey]=useState(0);
 const changed=venue!==originalVenue||(venue==='CME'&&base.cmeExpiry?.mode!==cmePolicy)||!!rebuilt||lowEdited||highEdited||iv!==base.iv||ivMode==='per-leg'||ivMode!==(base.optionIVMode??'reference')||premiumFunding!==(base.premiumFunding??'internal');
 const presentationSettings=useMemo(()=>({...snapshot.probability,benchmarkRate:.0475,compound:false}),[snapshot.probability]);
 // Moving the scenario cursor does not reprice or recreate the strategy. This
 // keeps seeded historical simulations stable while dragging the PnL chart.
 const effectiveIVMode=ivMode==='reference'&&!config.controls.referenceIV?'per-leg':ivMode;
 const c=useMemo(()=>({...current,low:lowEdited?low:current.low,high:highEdited?high:current.high,iv,optionIVMode:effectiveIVMode==='per-leg'?'uniform' as const:effectiveIVMode,premiumFunding}),[current,low,high,lowEdited,highEdited,iv,effectiveIVMode,premiumFunding]);
 const legs=useMemo(()=>currentLegs.map(l=>({...l,strike:lowEdited&&isLow(l,base.mode)?low:highEdited&&isHigh(l,base.mode)?high:l.strike,modelIV:effectiveIVMode==='per-leg'?(legIVs[l.id]??l.modelIV??(l.type==='call'?.08:.085)):undefined})),[currentLegs,base.mode,low,high,lowEdited,highEdited,effectiveIVMode,legIVs]);
 const results=useMemo(()=>{
  const out={} as Record<'OTC'|'CME',{r:StrategyResult|null;error:string;warnings:string[];market?:Market}>;
  for(const v of ['OTC','CME'] as const){
   if(!allowedVenues.includes(v)){out[v]={r:null,error:'管理员已隐藏此交易方式。',warnings:[]};continue;}
   try{
    if((lowEdited||highEdited)&&(!(low>0&&high>low)))throw Error('两个行权价须为正，且下行权价必须低于上行权价。');
    if(!(iv>0&&iv<3))throw Error('模型 IV 必须大于 0% 且小于 300%。');
    const built=buildPresentationVenue(c,legs,currentMarket,snapshot.overrides,v,cmePolicy);
    out[v]={r:strategy(built.c,built.legs,built.market,snapshot.overrides),error:'',warnings:built.warnings,market:built.market};
   }catch(error){out[v]={r:null,error:error instanceof Error?error.message:'当前参数无法计算',warnings:[]};}
  }
  return out;
 },[c,legs,currentMarket,snapshot.overrides,low,high,lowEdited,highEdited,iv,cmePolicy,venueKey]);
 const calculated=results[venue],r=calculated.r,greekR=useMemo(()=>r?{...r,c:{...r.c,scenario:spot}}:null,[r,spot]);
 const displayMarket=calculated.market??currentMarket;
 const reset=()=>{setLow(initialLow);setHigh(initialHigh);setLowEdited(false);setHighEdited(false);setIv(base.iv);setIvMode('per-leg');setLegIVs(initialLegIVs());setPremiumFunding(base.premiumFunding??'internal');setChosenVenue(initialVenue);setCmePolicy(base.cmeExpiry?.mode==='before-roll'?'before-roll':'after-close');setRebuilt(null);setFunding({equity:base.equity,start:base.start,durationDays:days(base.start,base.end),sizing:'proportional'});setFundingError('');setCases([{id:'down',name:'瑞郎贬值 10%',changePct:-10},{id:'flat',name:'瑞郎汇率不变',changePct:0},{id:'up',name:'瑞郎升值 10%',changePct:10}]);setSelectedCase('flat');setCaseError('');setStressSpot(base.spot*1.2);setResetKey(x=>x+1);};
 const rebuild=()=>{try{const result=rebuildPresentationFunding(snapshot,funding);setRebuilt(result);if(result.dateChanged&&ivMode==='reference')setIvMode('per-leg');setFundingError('');setResetKey(x=>x+1);}catch(e){setFundingError(e instanceof Error?e.message:'无法重建试算');}};
 const addCase=()=>{try{const changePct=Number(newChange);if(!newChange.trim())throw Error('请输入瑞郎到期变化。');spotFromCHFChange(base.spot,changePct);if(cases.length>=12)throw Error('最多保留 12 个情景，请先删除一个。');const id=`scenario-${Date.now()}-${cases.length}`;setCases(v=>[...v,{id,name:newName.trim()||`瑞郎变化 ${number(changePct,2)}%`,changePct}]);setSelectedCase(id);setCaseError('');}catch(e){setCaseError(e instanceof Error?e.message:'情景无效');}};
 const editChange=(id:string,value:string)=>{try{if(!value.trim())throw Error('请输入有效涨跌幅。');const changePct=Number(value);spotFromCHFChange(base.spot,changePct);setCases(v=>v.map(x=>x.id===id?{...x,changePct}:x));setCaseError('');}catch(e){setCaseError(e instanceof Error?e.message:'情景无效');}};
 const multipleLow=new Set(lowLegs.map(l=>l.strike)).size>1,multipleHigh=new Set(highLegs.map(l=>l.strike)).size>1;
 const quoted=displayMarket.rows.length>0;
 return <main className={`workspace presentation-workspace ${variant==='workbench'?'presentation-workbench':''}`}>
  <div className="presentation-hero">
   <div><div className="eyebrow">CHF COLLAR · {variant==='workbench'?'策略试算':'客户展示'}</div><h1>{config.title||'瑞郎领口对冲方案'}</h1><p>先看保护范围，再看不同汇率结果。</p></div>
   <button type="button" className="ghost" onClick={reset}>重置展示参数</button>
  </div>
  {adminPreview&&<div className="notice">{config.audience==='admin'?'管理员展示视图：页面按管理员自己的展示设置呈现。':'客户版预览：页面按客户展示设置呈现。'}此处调整仅影响本次试算；共享方案需在管理页面重新发布。</div>}
  <div className="presentation-status"><span className="pill">{changed?'新方案模型重算':'已发布方案'}</span><span>目标日 {current.end}</span><span>汇率单位 USD/CHF · 1 CHF 的美元价格</span><span>非实时成交承诺</span></div>
  <section className="panel presentation-venues"><div className="panel-heading"><div><div className="eyebrow">CHOOSE THE HEDGE</div><h2>{allowedVenues.length>1?'选择 OTC 或 CME，比较执行方式':venue==='OTC'?'OTC 场外期权方案':'CME 交易所期权方案'}</h2></div></div>
   <div className="presentation-control-grid"><label className="field"><span>期权交易方式</span><select aria-label="客户期权交易方式" value={venue} onChange={e=>{setChosenVenue(e.target.value as 'OTC'|'CME');setResetKey(x=>x+1);}}>{allowedVenues.map(v=><option key={v} value={v}>{v==='OTC'?'OTC · 银行场外期权':'CME · 交易所期权'}</option>)}</select><small>{allowedVenues.length>1?'切换是同一资金安排下的新方案试算；行权价、方向及申报数量保留。':'按下方行权价、方向、数量和期限设计新方案，并非实际成交确认。'}</small></label>{venue==='CME'&&<label className="field"><span>CME 期限安排</span><select aria-label="客户 CME 期限安排" value={cmePolicy} onChange={e=>{setCmePolicy(e.target.value as 'before-roll'|'after-close');setResetKey(x=>x+1);}}><option value="after-close">选目标日之后最近到期 · 还款日平仓</option><option value="before-roll">选目标日之前最近到期 · 提前滚仓</option></select><small>仅采用已提供且当时已挂牌的合约；找不到时明确显示不可计算。</small></label>}</div>
   <p className="mini">{config.controls.otc&&'OTC 可按约定名义金额及期限设计，实际条款与价格须向银行确认。'}{config.controls.cme&&'CME 按每手 125,000 CHF 和实际到期日计算，取整后可能留下敞口。晚到期期权在目标日按剩余价值平仓；早到期安排含未来滚仓预算。'}</p>
   {calculated.warnings.length>0&&<details><summary>查看此交易方式的计算口径与限制</summary><ul>{calculated.warnings.map((w,i)=><li key={i}>{w}</li>)}</ul></details>}
   {r&&<details><summary>查看逐步操作与实际合约</summary><ol><li>按当前本金与融资设置安排资金，预留保证金和流动性储备。</li><li>按下列方向、行权价、实际数量和期限建立期权，计入模型权利金、价差与手续费。</li><li>{venue==='OTC'?'按实际约定期限结算期权；若期限与目标日不同，使用已说明的跨期模型。':cmePolicy==='before-roll'?'在所选旧合约到期前安排平旧开新，计入滚仓现金、融资与退出预算。':'在目标日平仓仍未到期的期权，剩余价值由期限、IV、期货与现货关系共同决定。'}</li><li>目标日偿付瑞郎本息／变现瑞郎资产，汇总美元净资产与完整净收益。</li></ol><Table heads={['方向','行权价','实际数量 CHF','期权到期日','定价 IV']} rows={r.legs.map(l=>[`${l.venue} ${l.side==='buy'?'买入':'卖出'} ${l.type.toUpperCase()}`,number(l.strike,5),number(l.h),l.expiry,percent(l.iv)])}/><p className="mini">保证金 {money(r.c.margin)}，储备 {money(r.c.reserve)}；价差、深度、冲击、手续费与利率沿用已发布假设。上述占用不是券商保证金报价，未来追保与实际成交仍需确认。</p></details>}
  </section>
  {section.funding&&<section className="panel presentation-funding"><div className="panel-heading"><div><div className="eyebrow">YOUR CAPITAL & HORIZON</div><h2>用自己的本金与期限，重建一份试算</h2></div></div>
   <div className="presentation-control-grid"><label className="field"><span>客户本金 USD</span><input aria-label="客户本金 USD" type="number" min="1" max="1000000000000" step="10000" value={Number.isFinite(funding.equity)?funding.equity:''} onChange={e=>setFunding(v=>({...v,equity:Number(e.target.value)}))}/></label><label className="field"><span>开始日期</span><input aria-label="客户策略开始日期" type="date" value={funding.start} onChange={e=>setFunding(v=>({...v,start:e.target.value}))}/></label><label className="field"><span>策略期限 · 天</span><input aria-label="客户策略期限天数" type="number" min="1" max="3653" step="1" value={Number.isFinite(funding.durationDays)?funding.durationDays:''} onChange={e=>setFunding(v=>({...v,durationDays:Number(e.target.value)}))}/></label><label className="field"><span>期权数量调整方式</span><select aria-label="客户重建期权数量方式" value={funding.sizing} onChange={e=>setFunding(v=>({...v,sizing:e.target.value as PresentationFundingInput['sizing']}))}><option value="proportional">按新本息等比例调整期权数量 · 新方案</option><option value="fixed">保持原期权数量</option></select><small>只有点击下方按钮才应用。本息比例保留原覆盖关系。{config.controls.cme&&'CME 按整手规则取整。'}</small></label></div>
   <button type="button" onClick={rebuild}>按新本金与期限重建试算</button>{fundingPending&&<p className="notice">输入尚未应用。点击“按新本金与期限重建试算”后，才会更新下方图表、概率与情景数据。</p>}<p className="mini">当前图表：本金 {money(current.equity)}；{current.start} → {current.end}，{days(current.start,current.end)} 天。借款倍数模式随本金调整借款；手动借款金额、保证金、储备及固定费用保持原值。新日期停用原期权链报价；逐腿 IV 保留为新方案假设。</p>
   {base.mode==='loan'&&<label className="field"><span>资金安排模式 · 切换即重算</span><select aria-label="客户期权费用支付方式" value={premiumFunding} onChange={e=>setPremiumFunding(e.target.value as NonNullable<Config['premiumFunding']>)}><option value="internal">原有模式 · 费用从存款资金扣除</option><option value="external">新增模式 · 全额存款 · 期权费用外付</option></select><small>{premiumFunding==='external'?'本金与瑞郎借款换得的美元全额存入银行；期权及其他期初费用由客户另付，保证金与储备另行备资。额外投入不算利润，期权成本仍扣入净收益。':'先扣除净权利金、期初费用、保证金和储备，再用余额存款；保留原有计算方式。'}</small></label>}
   {fundingError&&<p className="error" role="alert">{fundingError} 图表仍保留上一次有效试算。</p>}
   {rebuilt&&<details className="presentation-rebuild-notes"><summary>本次重建做了哪些调整？</summary><ul>{rebuilt.warnings.map((warning,i)=><li key={i}>{warning}</li>)}</ul><p className="mini">本次期权申报数量比例：{number(rebuilt.quantityScale,5)} 倍。{config.controls.otc&&'OTC 保留相对目标日的期限差。'}{config.controls.cme&&'自动 CME 重选实际合约，手动 CME 保留原到期日。'}所有结果是新方案设计，不改写已成交交易的历史成本。</p></details>}
  </section>}
  {section.context&&<details className="panel presentation-context"><summary>方案资金与期限概况</summary>
   <div className="presentation-facts"><div><span>客户本金</span><strong>{money(current.equity)}</strong></div><div><span>{base.mode==='loan'?'融资方式':'资产方向'}</span><strong>{base.mode==='loan'?'瑞郎融资 → 美元投资':'瑞郎资产 → 美元计价'}</strong>{r&&<small>{base.mode==='loan'?`借款 ${number(r.c.loan)} CHF · 到期本息 ${number(r.n)} CHF`:`目标日瑞郎资产 ${number(r.n)} CHF`}</small>}</div><div><span>策略期限</span><strong>{days(current.start,current.end)} 天</strong><small>{current.start} → {current.end}</small></div><div><span>发布时汇率起点</span><strong>{number(base.spot,5)}</strong></div></div>
   <p className="mini">本页读取管理员发布的工作台方案。本金与期限需点击“重建试算”后应用；行权价、IV 与汇率可在本次会话探索。利率、成本和融资条款仍是原方案假设，需要另外询价。</p><p className="mini">市场参考时间：{displayMarket.asOf||'未提供'} · {displayMarket.source||'未提供来源'}。这是已发布快照或明确标注的新方案模型，页面刷新不代表实时行情更新。</p>
  </details>}
  {(section.strikes||section.iv)&&<section className="panel presentation-controls">
   <div className="panel-heading"><div><div className="eyebrow">EXPLORE THE COLLAR</div><h2>调整两个行权价，看保护与成本如何变化</h2></div>{changed&&<span className="pill">试算中</span>}</div>
   <div className="presentation-control-grid">
    {section.strikes&&<><label className="field"><span>{base.mode==='loan'?'卖出 Put · 下行权价':'买入 Put · 下行权价'}</span><input aria-label="客户试算下行权价" type="number" min="0" step="0.005" value={Number.isFinite(low)?low:''} disabled={!lowLegs.length} onChange={e=>{setLow(Number(e.target.value));setLowEdited(true);}}/><small>{lowLegs.length?`${lowLegs.length} 条匹配腿 · 修改时统一采用该行权价`:'已发布方案没有对应启用腿'}</small></label><label className="field"><span>{base.mode==='loan'?'买入 Call · 上行权价':'卖出 Call · 上行权价'}</span><input aria-label="客户试算上行权价" type="number" min="0" step="0.005" value={Number.isFinite(high)?high:''} disabled={!highLegs.length} onChange={e=>{setHigh(Number(e.target.value));setHighEdited(true);}}/><small>{highLegs.length?`${highLegs.length} 条匹配腿 · 修改时统一采用该行权价`:'已发布方案没有对应启用腿'}</small></label></>}
    {section.iv&&<><label className="field"><span>期权模型 IV 口径</span><select aria-label="客户期权 IV 口径" value={effectiveIVMode} onChange={e=>setIvMode(e.target.value as 'reference'|'uniform'|'per-leg')}><option value="per-leg">逐腿 IV · 每条期权单独定价</option>{config.controls.referenceIV&&<option value="reference">沿用已发布参考 IV</option>}<option value="uniform">统一模型 IV · 原有方式</option></select><small>{effectiveIVMode==='per-leg'?'每条腿采用下方独立 IV，同时重算期初权利金和未到期价值。':quoted?'参考模式仅在合约与行权价匹配时使用已发布期权链。':'无匹配期权链时使用统一输入 IV。'}</small></label>{effectiveIVMode==='uniform'&&<label className="field"><span>统一模型 IV %</span><input aria-label="客户模型 IV 百分比" type="number" min="0.01" max="299.99" step="0.1" value={Number.isFinite(iv)?iv*100:''} onChange={e=>setIv(Number(e.target.value)/100)}/></label>}
    {effectiveIVMode==='per-leg'&&legs.filter(active).map((l,i)=><label className="field" key={l.id}><span>第 {i+1} 腿 · {l.side==='buy'?'买入':'卖出'} {l.type.toUpperCase()} · K {number(l.strike,4)} · IV %</span><input aria-label={`客户第${i+1}腿 ${l.type} IV 百分比`} type="number" min="0.01" max="299.99" step="0.1" value={Number.isFinite(l.modelIV)?Number((l.modelIV!*100).toFixed(8)):''} onChange={e=>setLegIVs(v=>({...v,[l.id]:Number(e.target.value)/100}))}/><small>{number(l.notional)} CHF · 到期日由所选交易方式确定</small></label>)}</>}
   </div>
   {section.strikes&&(multipleLow||multipleHigh)&&<p className="warning">已发布方案包含多个不同的{[multipleLow?'下':null,multipleHigh?'上':null].filter(Boolean).join('／')}行权价。尚未改动的腿保留原值；修改某一侧时，该侧全部匹配启用腿会统一到输入值。数量、方向和期限不变。</p>}
   <p className="mini">{base.mode==='loan'?'上行权价决定何时开始补偿瑞郎升值风险；下行权价决定何时让出瑞郎贬值的部分好处。':'下行权价决定何时开始补偿瑞郎贬值风险；上行权价决定何时让出瑞郎升值的部分好处。'}改变行权价或 IV 是重新设计方案；已成交交易的历史成本不会因此改变。</p>
   {section.iv&&<p className="mini">期权 IV 用于期权定价；概率模型中的波动率用于描述假设分布。两者可以不同，需要分别说明。逐腿初始值采用你提供的 Call 8%、Put 8.5% 示例，已有逐腿设置则保留；不是实时银行报价，也不随行权价自动校准微笑。改变行权价、期限或现价后，请分别核对每条腿 IV。统一 IV 方式仍可选择。</p>}
  </section>}
  {!lowEdited&&!highEdited&&lowLegs.length>0&&highLegs.length>0&&initialLow>=initialHigh&&<div className="warning">已发布方案的 Put 行权价不低于 Call 行权价，属于非标准领口安排。此页保留原腿计算，请核对结构；调整为下行权价低于上行权价后可比较标准领口。</div>}
  {calculated.error&&<div className="error" role="alert">{calculated.error} 请调整输入后继续查看结果。</div>}
  {r&&<>
   {(section.iv||premiumFunding==='external')&&<section className="panel presentation-premium-plan"><div className="panel-heading"><div><div className="eyebrow">OPTION COST & FUNDING</div><h2>{premiumFunding==='external'?'全额存款 · 期权费用外付':'逐腿期权费用预估'}</h2><p className="mini">按每条腿的 IV、方向、数量、期限及成交价差计算；不是银行可成交报价。</p></div></div>
    <Table heads={['期权腿','行权价','实际名义 CHF','定价 IV','买入支出 USD','卖出收入 USD','开仓费 USD']} rows={r.legs.map((l,i)=>[`${i+1} · ${l.venue} ${l.side==='buy'?'买':'卖'} ${l.type.toUpperCase()}`,number(l.strike,5),number(l.h),percent(l.iv),l.side==='buy'?money(l.premium,2):'—',l.side==='sell'?money(-l.premium,2):'—',money(l.fee,2)])}/>
    <div className="presentation-facts"><div><span>净期权费用预估</span><strong>{money(r.premium+r.feesOptions,2)}</strong><small>买入支出 − 卖出收入 + 开仓费；负数为净收款</small></div><div><span>银行美元存款本金</span><strong>{money(r.deposit,2)}</strong><small>{premiumFunding==='external'?'本金 + 瑞郎借款换得的美元':'扣除已设费用与资金占用后的余额'}</small></div><div><span>保证金与储备</span><strong>{money(r.c.margin+r.c.reserve,2)}</strong><small>可返还资金占用，独立于期权费用；可能需要追加</small></div></div>
    {premiumFunding==='external'&&<><div className="presentation-facts"><div><span>客户需额外准备现金</span><strong>{money(r.externalCashRequired,2)}</strong><small>净权利金、全部期初费用、保证金及储备合计后的净备资</small></div><div><span>额外净投入／期初分配</span><strong>{money(r.externalContribution,2)}</strong><small>正数是追加自有资金；负数是净收款分配给客户</small></div><div><span>客户自有资金净投入合计</span><strong>{money(r.contributedCapital,2)}</strong><small>原本金 + 额外净投入；不含银行借款</small></div></div><p className="notice">总净收益 = 到期净资产 − 原本金 − 额外净投入。外付期权费用已扣入图表、全域上下界、概率、到期案例和 Excel，未重复扣除；可返还保证金与储备不作为费用。本金收益率仍以原本金为分母；当前情景按全部净投入计算的收益率为 {r.contributedCapital>0?percent(r.pnl(spot)/r.contributedCapital):'不适用'}。只存本金的 4.75% 基准仍按原本金计算，未给额外现金假设其他投资收益。</p></>}
   </section>}
   <div className="metrics presentation-metrics">
    {section.scenarios&&<Metric label="所选目标日情景净收益" value={money(r.pnl(spot))} sub={`S = ${number(spot,5)} · 本金收益率 ${percent(r.pnl(spot)/r.c.equity)}`} tone={r.pnl(spot)>=0?'teal':''}/>}
    {section.bounds&&<><Metric label={r.exact?'模型收益下界':'条件模型收益下界'} value={boundText(r,'min')} sub={r.bound?'覆盖所有 S ≥ 0；非图中最低点':'自定义公式未支持边界认证'} tone="teal"/><Metric label={r.exact?'模型收益上界':'条件模型收益上界'} value={boundText(r,'max')} sub={r.bound?`全域计算 · ${r.bound.converged?'已收敛':'未收敛，请审慎解读'}`:'恢复标准模型后可计算'}/></>}
   </div>
   <div className={r.exact&&r.tailCovered?'notice':'warning'}>{r.legs.length===0?'当前方案没有启用期权；保护程度取决于已发布的远期及资金安排。':r.exact?'此方案使用同日到期的 OTC 现货赔付模型。':venue==='CME'?'此方案使用 CME 期货期权及已选期限安排。上下界依赖已设置的基差、路径、IV 与成交成本；还款日未到期期权按剩余价值平仓。':'此 OTC 方案存在跨期限安排。提前结算后的资金及汇率敞口按既定路径处理；目标日未到期期权按剩余价值估值，结果受剩余期限、IV 和退出成本影响。'}{` 当前不利尾部模型覆盖 ${percent(r.coverage)}。`}{!r.tailCovered&&' 当前组合仍有不利尾部敞口；不能宣称收益与亏损都已锁定。'}{section.bounds&&r.bound&&(!Number.isFinite(r.bound.min)||!Number.isFinite(r.bound.max))&&' 存在无有限边界的一侧，请展开风险范围。'}</div>
   {section.chart&&<PresentationChart key={resetKey} r={r} settings={presentationSettings} history={snapshot.history} allowedModels={config.allowedModels} defaultModels={config.defaultModels} spot={spot} onSpot={setSpot} showProbabilities={section.probabilities} showScenarios={section.scenarios} showPolicyGuide={config.controls.policyGuide}/>}
   {section.scenarios&&<section className="panel presentation-cases"><div className="panel-heading"><div><div className="eyebrow">COMPARE YOUR SCENARIOS</div><h2>添加瑞郎到期变化，逐一比较结果</h2></div></div><p className="mini">涨跌幅以发布时 1 CHF = {number(base.spot,5)} USD 为起点。正数表示瑞郎升值，负数表示贬值。以下是汇率假设，不是概率分位数；最多保留 12 个情景。拖动图表仅调整当前选中的情景。</p>
    <div className="presentation-stress-row"><label className="field"><span>瑞郎到期变化 %</span><input aria-label="新增瑞郎到期变化百分比" type="number" min="-99.999" max="10000" step="1" value={newChange} onChange={e=>setNewChange(e.target.value)}/></label><label className="field"><span>情景名称 · 可选</span><input aria-label="新增汇率情景名称" type="text" maxLength={60} value={newName} onChange={e=>setNewName(e.target.value)}/></label><button type="button" className="ghost" onClick={addCase} disabled={cases.length>=12}>添加到期情景</button></div>
    {caseError&&<p className="error" role="alert">{caseError}</p>}
    <Table heads={['情景名称','瑞郎变化 %','现货 S · USD/CHF','组合净收益','到期净资产','本金收益率','较不对冲','较 4.75% 存款','操作']} rows={cases.map(x=>{const v=presentationScenarioDetails(r,spotFromCHFChange(base.spot,x.changePct));return[<input key={`name-${x.id}`} aria-label={`${x.name} 情景名称`} maxLength={60} value={x.name} onChange={e=>setCases(old=>old.map(row=>row.id===x.id?{...row,name:e.target.value}:row))}/>,<input key={`pct-${x.id}`} aria-label={`${x.name} 瑞郎变化百分比`} type="number" min="-99.999" max="10000" step="1" value={Number(x.changePct.toFixed(5))} onChange={e=>editChange(x.id,e.target.value)}/>,number(v.spot,5),money(v.pnl),money(v.endEquity),percent(v.returnRate),money(v.versusBare),money(v.versusBenchmark),<div className="presentation-case-actions" key={`actions-${x.id}`}><button type="button" className="ghost" aria-pressed={x.id===selected.id} onClick={()=>setSelectedCase(x.id)}>{x.id===selected.id?'已选中':'查看'}</button><button type="button" className="ghost" disabled={cases.length===1} onClick={()=>{setCases(old=>old.filter(row=>row.id!==x.id));if(x.id===selected.id)setSelectedCase(cases.find(row=>row.id!==x.id)!.id);}}>删除</button></div>];})}/>
    <ScenarioDetails r={r} spot={spot} name={selected.name} overrides={snapshot.overrides}/>
    {config.controls.policyStress&&<details className="presentation-policy-stress"><summary>单独查看政策冲击／瑞郎跳升压力情景</summary><p className="mini">默认只是假设瑞郎升值 20%，不是对政策变化的预测。可输入其他目标日汇率，并使用上方 IV 控件另做估值压力。</p><div className="presentation-stress-row"><label className="field"><span>压力情景：目标日 USD/CHF</span><input aria-label="政策压力目标汇率" type="number" min="0.0001" step="0.01" value={Number.isFinite(stressSpot)?stressSpot:''} onChange={e=>setStressSpot(Number(e.target.value))}/></label><div><span>该目标日情景的模型净收益</span><strong>{stressSpot>0&&Number.isFinite(stressSpot)?money(r.pnl(stressSpot)):'请输入正的有限汇率'}</strong><small>{stressSpot>0&&Number.isFinite(stressSpot)?`瑞郎涨跌 ${percent(stressSpot/base.spot-1)}`:'无法计算'}</small></div><button type="button" className="ghost" disabled={!(stressSpot>0&&Number.isFinite(stressSpot))} onClick={()=>setSpot(stressSpot)}>在当前情景查看</button></div><p className="warning">政策压力情景，不赋予发生概率。到期图不代表期间追保；政策发生时间、跳跃、IV、基差、流动性和银行条款仍需单独分析。</p></details>}</section>}
   {config.controls.excel&&<PresentationExport results={results} activeVenue={venue} allowedVenues={allowedVenues} settings={presentationSettings} history={snapshot.history} spot={spot} caseName={selected.name} market={currentMarket} overrides={snapshot.overrides}/>}
   {section.bounds&&<BoundaryDetails r={r}/>}
   {section.costs&&<section className="panel presentation-costs"><div className="panel-heading"><div><div className="eyebrow">COST & LIQUIDITY</div><h2>费用与资金占用，要分开看</h2></div></div><div className="presentation-facts"><div><span>期初净权利金</span><strong>{money(r.premium)}</strong><small>{r.premium<0?'负数表示期初净收款':'买入支出减去卖出收入'}</small></div><div><span>期初全部费用</span><strong>{money(r.fees0)}</strong><small>期权、换汇与远期已设费用合计</small></div><div><span>保证金与储备</span><strong>{money(r.c.margin+r.c.reserve)}</strong><small>资金占用；可能追加，不等同于损失</small></div><div><span>目标日期权退出成本预算</span><strong>{money(r.totalOptionExit)}</strong><small>仅当前已设置的晚到期／滚仓退出预算</small></div></div><p className="mini">权利金与费用已进入图中收益。保证金及储备按模型处理释放和利息，不能重复当作交易亏损。未来保证金与实际成交价差并未被固定。{r.deposit<0?' 当前方案存在美元融资缺口，已按所设融资利率计息；请核对实际可用资金。':''}</p></section>}
   {section.context&&<PresentationGuide r={r}/>}
   {variant==='workbench'&&<details className="panel presentation-holdings"><summary>查看当前试算的实际腿、期限与数据来源</summary><p className="mini">此表用于核对演示方案。所有修改仅保存在本页会话，不会发布或更改管理员工作台。</p><Table heads={['期权','行权价','实际 CHF 数量','到期日','IV','定价来源']} rows={r.legs.map(l=>[`${l.venue} · ${l.side==='buy'?'买':'卖'} ${l.type.toUpperCase()}`,number(l.strike,5),number(l.h),l.expiry,percent(l.iv),`${l.ivSource}；${l.quote.source}`])}/>{r.forwards.length>0&&<Table heads={['远期','CHF 数量','约定汇率','费用 USD']} rows={r.forwards.map(f=>[`${f.side==='buy'?'买入':'卖出'} CHF`,number(f.notional),number(f.strike,5),money(f.fee)])}/>}<p className="mini">市场来源：{displayMarket.source||'未提供'}；原始数据时间：{displayMarket.asOf||'未提供'}。检索或发布时间不一定是市场报价日期，模型输入不可视为实时价格。</p></details>}
   {section.greeks&&greekR&&<OptionGreeksPanel r={greekR} showFormulaLink={false}/>}
  </>}
  <p className="presentation-footer mini">演示基于管理员于 {config.updatedAt?new Date(config.updatedAt).toLocaleString('zh-CN',{timeZone:'Asia/Hong_Kong',hour12:false}):'未记录时间'} 发布的方案。结果是给定假设下的模型计算，不是收益承诺；概率、估值、现金可用性与实际成交应分别核对。</p>
 </main>;
}

function ScenarioDetails({r,spot,name,overrides}:{r:StrategyResult;spot:number;name:string;overrides:Overrides}){
 const v=presentationScenarioDetails(r,spot),labels:Record<keyof typeof v.parts,string>={usdInterest:'美元存款／融资及滚仓资金利息',principalFX:'瑞郎本金汇兑损益',chfInterest:'瑞郎利息的美元价值',options:'期权及远期全生命周期价值',premium:'期初净权利金（支出为负）',fees:'交易、换汇、退出及滚仓费用',collateralInterest:'保证金利息'};
 return <div className="presentation-selected-case"><h3>当前情景：{name||'未命名情景'}</h3><div className="presentation-facts"><div><span>到期净收益／本金收益率</span><strong>{money(v.pnl)}</strong><small>{percent(v.returnRate)}</small></div><div><span>到期净资产</span><strong>{money(v.endEquity)}</strong><small>{r.externalContribution!==0?`本金 + 额外净投入 ${money(r.externalContribution)} + 净收益`:'本金 + 净收益'}</small></div><div><span>{r.c.mode==='loan'?'到期瑞郎还款本息':'目标日瑞郎资产'}</span><strong>{number(v.chfTarget)} CHF</strong><small>到期汇率 {number(spot,5)} USD/CHF</small></div><div><span>期权／远期生命周期价值</span><strong>{money(v.optionValue)} / {money(v.forwardValue)}</strong><small>期权含已设滚仓现金；期初成本另列</small></div><div><span>不对冲净收益</span><strong>{money(v.unhedgedPnl)}</strong><small>对冲方案比其多 {money(v.versusBare)}</small></div><div><span>本金单存 4.75% 的净收益</span><strong>{money(v.benchmark)}</strong><small>相同 {days(r.c.start,r.c.end)} 天，单利 ACT/365；差额 {money(v.versusBenchmark)}</small></div></div>
  <details><summary>展开该情景的收益分解与资产核对</summary><Table heads={['收益构成','USD']} rows={(Object.keys(v.parts) as (keyof typeof v.parts)[]).map(key=>[<FormulaButton key={key} r={r} spot={spot} itemId={key} label={labels[key]} overrides={overrides}/>,money(v.parts[key],2)])}/><Table heads={['核对项','USD']} rows={[
   [<FormulaButton r={r} spot={spot} itemId="partsTotal" label="收益分项合计" overrides={overrides}/>,money(Object.values(v.parts).reduce((a,b)=>a+b,0),2)],[<FormulaButton r={r} spot={spot} itemId="pnl" label="组合净收益" overrides={overrides}/>,money(v.pnl,2)],[<FormulaButton r={r} spot={spot} itemId="assets" label="到期总资产" overrides={overrides}/>,money(v.book.assets,2)],[<FormulaButton r={r} spot={spot} itemId="liabs" label="到期总负债与退出成本" overrides={overrides}/>,money(v.book.liabs,2)],[<FormulaButton r={r} spot={spot} itemId="equity" label="净资产 = 总资产 − 总负债" overrides={overrides}/>,money(v.book.equity,2)],[<FormulaButton r={r} spot={spot} itemId="check" label="净资产核对误差" overrides={overrides}/>,money(v.book.check,4)]
  ]}/></details>
 </div>;
}

function BoundaryDetails({r}:{r:StrategyResult}){
 return <details className="panel presentation-boundaries"><summary>保护范围与边界条件</summary><Table heads={['检查项','当前结果']} rows={[
  ['整个资金组合的模型收益下界',boundText(r,'min')],['整个资金组合的模型收益上界',boundText(r,'max')],['不利尾部模型覆盖',percent(r.coverage)],['期权到期是否与目标日严格匹配',r.exact?'同日 OTC 现货赔付':r.legs.some(l=>l.venue==='CME')?'存在 CME 期货口径、跨期或滚仓条件':'存在 OTC 跨期估值条件'],['边界计算',r.bound?`${r.bound.method==='piecewise'?'折点解析':'Black 全域包络'}；误差预算 ${money(r.bound.error,2)}；${r.bound.converged?'已收敛':'未收敛'}`:'当前自定义公式不支持全域认证']
 ]}/><p className="mini">边界检查全部非负汇率，而不是只搜索图表横轴。有限的上下界只在当前数量、利率、IV、到期安排、基差与滚仓假设下成立。保护到期结果与持有期间是否追保，是两个不同的问题。出现“无上界／无下界”时，不能用图中最高／最低点替代。</p>{!r.exact&&<p className="warning">早到期期权先结算，之后仍需偿付／换汇；晚到期期权在目标日仍有时间价值，其平仓价格受剩余期限、IV、基差、盘口影响。当前全局界限是条件模型结果。</p>}</details>;
}
