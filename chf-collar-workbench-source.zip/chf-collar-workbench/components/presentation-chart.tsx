'use client';
import {useEffect,useId,useMemo,useState,type PointerEvent} from 'react';
import type {StrategyResult} from '@/lib/strategy';
import {outcomeProbabilities,type ProbabilitySettings,type SpotHistory} from '@/lib/probability';
import {presentationModels,presentationModelGuides,presentationDistribution,presentationOutcomes,presentationRange,probabilityBins,type PresentationModel} from '@/lib/presentation-probability';
import {presentationExpectation} from '@/lib/presentation-expectation';
import type {Crossing} from '@/lib/outcome-analysis';
import {money,number,percent} from './lab-ui';
import SvgPointTooltips,{type SvgTooltipPoint} from './svg-point-tooltips';

type Props={r:StrategyResult;settings:ProbabilitySettings;history:SpotHistory|null;allowedModels:string[];defaultModels?:string[];spot:number;onSpot:(v:number)=>void;showProbabilities:boolean;showScenarios:boolean;showPolicyGuide?:boolean};
const COLORS:Record<PresentationModel,string>={physical:'#2563b7',historical:'#008477',bootstrap:'#966629',fhs:'#8a56ab',neutral:'#bf4d66'};
const historyModel=(id:PresentationModel)=>id==='historical'||id==='bootstrap'||id==='fhs';
export default function PresentationChart({r,settings,history,allowedModels,defaultModels,spot,onSpot,showProbabilities,showScenarios,showPolicyGuide=true}:Props){
 const modelKey=JSON.stringify(presentationModels.filter(m=>allowedModels.includes(m.id)).map(m=>m.id));
 const models=useMemo(()=>presentationModels.filter(m=>(JSON.parse(modelKey) as string[]).includes(m.id)),[modelKey]);
 const defaultKey=JSON.stringify(defaultModels===undefined?(models.some(m=>m.id==='bootstrap')?['bootstrap']:models[0]?[models[0].id]:[]):models.filter(m=>defaultModels.includes(m.id)).map(m=>m.id));
 const [selected,setSelected]=useState<PresentationModel[]>(()=>JSON.parse(defaultKey)),[hedged,setHedged]=useState(true),[bare,setBare]=useState(true),[deposit,setDeposit]=useState(true),[strikes,setStrikes]=useState(true),[zeroPoints,setZeroPoints]=useState(true),[benchmarkPoints,setBenchmarkPoints]=useState(true),[unchanged,setUnchanged]=useState(true);
 useEffect(()=>{setSelected(JSON.parse(defaultKey));},[modelKey,defaultKey]);
 const clip=useId().replaceAll(':',''),range=useMemo(()=>presentationRange(r),[r]),outcome=useMemo(()=>presentationOutcomes(r,settings),[r]);
 const forward=r.fwd(r.c.spot,r.t);
 const distributions=useMemo(()=>showProbabilities?selected.filter(id=>models.some(m=>m.id===id)).map(id=>{try{const d=presentationDistribution(id,settings,r.c.spot,r.t,forward,r.c.start,history),bins=probabilityBins(d,range.min,range.max);return{id,d,bins,error:''};}catch(e){return{id,d:null,bins:null,error:e instanceof Error?e.message:'概率暂不可计算'};}}):[],[showProbabilities,selected,modelKey,settings,r.c.spot,r.t,forward,r.c.start,history,range]);
 const expectations=useMemo(()=>new Map(distributions.filter(m=>m.d).map(m=>[m.id,presentationExpectation(r,m.d!,m.id,settings)])),[distributions,r,settings]);
 const valid=distributions.filter(d=>d.d&&d.bins),points=useMemo(()=>Array.from({length:161},(_,i)=>{const s=range.min+(range.max-range.min)*i/160;return{s,pnl:r.pnl(s),bare:r.bare(s)};}),[r,range]);
 const values=[0,...points.flatMap(p=>[...(hedged?[p.pnl]:[]),...(bare?[p.bare]:[])]),...(deposit||benchmarkPoints?[outcome.benchmark]:[])],vmin=Math.min(...values),vmax=Math.max(...values),pad=Math.max(1,(vmax-vmin)*.09),low=vmin-pad,high=vmax+pad;
 const w=960,left=88,right=26,top=32,pnlBottom=324,probTop=392,probBottom=512,hasStrip=showProbabilities&&valid.length>0,h=hasStrip?566:382;
 const X=(s:number)=>left+(s-range.min)/(range.max-range.min)*(w-left-right),Y=(v:number)=>pnlBottom-(v-low)/(high-low)*(pnlBottom-top),path=(field:'pnl'|'bare')=>points.map((p,i)=>`${i?'L':'M'}${X(p.s).toFixed(2)},${Y(p[field]).toFixed(2)}`).join(' '),pmax=Math.max(.01,...valid.flatMap(d=>d.bins!.bins.map(b=>b.mass)))*1.12,PY=(v:number)=>probBottom-v/pmax*(probBottom-probTop);
 const positionInView=spot>=range.min&&spot<=range.max,scenario=r.pnl(spot),unchangedPnl=r.pnl(r.c.spot),unchangedInView=r.c.spot>=range.min&&r.c.spot<=range.max&&unchangedPnl>=low&&unchangedPnl<=high;
 const move=(e:PointerEvent<SVGSVGElement>)=>{const rect=e.currentTarget.getBoundingClientRect(),x=(e.clientX-rect.left)/rect.width*w;onSpot(Math.max(range.min,Math.min(range.max,range.min+(x-left)/(w-left-right)*(range.max-range.min))));};
 const markers=r.legs.map((l,i)=>({id:l.id,type:l.type,strike:l.strike,s:r.boundTerms[i]?.strike/r.boundTerms[i]?.alpha})).filter(l=>l.s>=range.min&&l.s<=range.max);
 const crossings=[...(zeroPoints&&outcome.zero?outcome.zero.roots.map((s,i)=>({key:`zero-${i}`,s,target:0,color:'#b2445a',label:'盈亏平衡点 · PNL = 0'})):[]),...(benchmarkPoints&&outcome.deposit?outcome.deposit.roots.map((s,i)=>({key:`deposit-${i}`,s,target:outcome.benchmark,color:'#a56b16',label:'追平本金存款点 · PNL = PNL_origin'})):[])].filter(p=>p.s>=range.min&&p.s<=range.max);
 const tooltipPoints:SvgTooltipPoint[]=[...crossings.filter(p=>p.target>=low&&p.target<=high).map(p=>({id:p.key,x:X(p.s),y:Y(p.target),color:p.color,title:p.label,details:[`S = ${number(p.s,7)} USD/CHF`,`目标日净收益 ${money(p.target,2)}`]})),...(unchanged&&unchangedInView?[{id:'unchanged-fx',x:X(r.c.spot),y:Y(unchangedPnl),color:'#d0661b',shape:'diamond' as const,title:'汇率不变点 · S_T = S₀',details:[`S_T = S₀ = ${number(r.c.spot,7)} USD/CHF`,`目标日 ${r.c.end} · 净收益 ${money(unchangedPnl,2)}`]}]:[])];
 return <section className="panel presentation-chart" aria-label="客户收益与汇率概率演示">
 <div className="panel-heading"><div><div className="eyebrow">SEE THE OUTCOME</div><h2>到期时，汇率变化会怎样影响收益？</h2><p className="mini">目标日 {r.c.end} · 横轴向右代表瑞郎升值。曲线显示整个资金组合的美元净收益，已包括模型内的融资、期权与费用。</p></div></div>
 <div className="chart-legend" role="group" aria-label="收益图显示条件">
 <label><input type="checkbox" checked={hedged} onChange={e=>setHedged(e.target.checked)}/>对冲后净收益</label>
 <label><input type="checkbox" checked={bare} onChange={e=>setBare(e.target.checked)}/>不对冲净收益</label>
 <label><input type="checkbox" checked={deposit} onChange={e=>setDeposit(e.target.checked)}/>只存初始美元本金</label>
 <label><input type="checkbox" checked={strikes} onChange={e=>setStrikes(e.target.checked)}/>行权价位置</label>
 <label><input type="checkbox" checked={zeroPoints} onChange={e=>setZeroPoints(e.target.checked)}/>盈亏平衡点 · PNL = 0</label>
 <label><input type="checkbox" checked={benchmarkPoints} onChange={e=>setBenchmarkPoints(e.target.checked)}/>追平本金存款点 · PNL = PNL_origin</label>
 <label><input type="checkbox" checked={unchanged} onChange={e=>setUnchanged(e.target.checked)}/>汇率不变点 · S_T = S₀</label></div>
 {showScenarios&&<div className="chart-readout"><span>假设到期 1 CHF = <b>{number(spot,5)} USD</b></span><span>瑞郎涨跌 <b>{percent(spot/r.c.spot-1)}</b></span><span>对冲后净收益 <b className={scenario>=0?'positive':'negative'}>{money(scenario,2)}</b></span><span>不对冲 {money(r.bare(spot),2)}</span></div>}
 <div style={{overflowX:'auto'}}><svg viewBox={`0 0 ${w} ${h}`} style={{width:'100%',minWidth:720,display:'block',touchAction:'pan-y'}} role="group" aria-label="上方为美元净收益曲线，下方为可选汇率区间概率；共用到期汇率横轴。点击改变演示情景。" onPointerDown={e=>{e.currentTarget.setPointerCapture(e.pointerId);move(e);}} onPointerMove={e=>{if(e.buttons)move(e);}}>
 <defs><clipPath id={clip}><rect x={left} y={top} width={w-left-right} height={pnlBottom-top}/></clipPath></defs>
 {Array.from({length:5},(_,i)=>{const v=low+(high-low)*i/4;return <g key={i}><line x1={left} x2={w-right} y1={Y(v)} y2={Y(v)} stroke="#e1e7eb"/><text x={left-10} y={Y(v)+4} textAnchor="end" className="axis">{number(v/1000,1)}k</text></g>;})}
 <text x={left} y={17} className="axis">USD 净收益 · 零线上方盈利，下方亏损</text>
 <g clipPath={`url(#${clip})`}>
 <line x1={left} x2={w-right} y1={Y(0)} y2={Y(0)} stroke="#8799a7" strokeDasharray="3 4"/>
 {bare&&<path d={path('bare')} fill="none" stroke="#8796a3" strokeWidth="2.2" strokeDasharray="7 5"/>}
 {deposit&&<line x1={left} x2={w-right} y1={Y(outcome.benchmark)} y2={Y(outcome.benchmark)} stroke="#ba8426" strokeWidth="2" strokeDasharray="9 5"/>}
 {hedged&&<path d={path('pnl')} fill="none" stroke="#008274" strokeWidth="3.8"/>}
 {strikes&&markers.map((l,i)=><g key={l.id}><line x1={X(l.s)} x2={X(l.s)} y1={top} y2={pnlBottom} stroke="#756388" strokeDasharray="4 4" opacity=".5"/><text x={X(l.s)+5} y={top+15+(i%3)*16} className="axis">{l.type==='call'?'Call':'Put'} K={number(l.strike,3)}</text></g>)}
 {crossings.map(p=><line key={p.key} x1={X(p.s)} x2={X(p.s)} y1={Y(p.target)} y2={pnlBottom} stroke={p.color} strokeDasharray="2 5" opacity=".6"/>)}
 {showScenarios&&positionInView&&<><line x1={X(spot)} x2={X(spot)} y1={top} y2={pnlBottom} stroke="#3c6680" strokeDasharray="3 4"/>{hedged&&<circle cx={X(spot)} cy={Y(scenario)} r="5.5" fill="#008274" stroke="white" strokeWidth="2"/>}</>}
 {unchanged&&unchangedInView&&<line x1={X(r.c.spot)} x2={X(r.c.spot)} y1={Y(unchangedPnl)} y2={pnlBottom} stroke="#d0661b" strokeDasharray="6 4"/>}
 </g>
 {hasStrip&&<><text x={left} y={probTop-17} className="axis">每个汇率区间的概率权重（%）· 柱高与上方 USD 纵轴不同</text>{[0,.5,1].map(i=><g key={i}><line x1={left} x2={w-right} y1={PY(pmax*i)} y2={PY(pmax*i)} stroke="#e1e7eb"/><text x={left-10} y={PY(pmax*i)+4} textAnchor="end" className="axis">{number(pmax*i*100,1)}%</text></g>)}
 {valid.map((m,j)=>m.bins!.bins.map((b,i)=>{const width=(X(b.hi)-X(b.lo))*.84/valid.length,x=X(b.lo)+(X(b.hi)-X(b.lo))*.08+j*width;return <rect key={`${m.id}-${i}`} x={x} y={PY(b.mass)} width={Math.max(.5,width-.5)} height={probBottom-PY(b.mass)} fill={COLORS[m.id]} opacity=".78"><title>{presentationModelGuides[m.id].short}：{number(b.lo,4)} {b.includeLo?'≤':'<'} S ≤ {number(b.hi,4)}，{percent(b.mass)}</title></rect>;}))}
 {strikes&&markers.map(l=><line key={l.id} x1={X(l.s)} x2={X(l.s)} y1={probTop} y2={probBottom} stroke="#756388" strokeDasharray="4 4" opacity=".35"/>)}{showScenarios&&positionInView&&<line x1={X(spot)} x2={X(spot)} y1={probTop} y2={probBottom} stroke="#3c6680" strokeDasharray="3 4"/>}</>}
 {Array.from({length:7},(_,i)=>{const s=range.min+(range.max-range.min)*i/6;return <g key={i}><line x1={X(s)} x2={X(s)} y1={pnlBottom} y2={pnlBottom+5} stroke="#9ba8b1"/>{hasStrip&&<line x1={X(s)} x2={X(s)} y1={probBottom} y2={probBottom+5} stroke="#9ba8b1"/>}<text x={X(s)} y={h-29} textAnchor="middle" className="axis">{number(s,3)}</text></g>;})}
 <text x={w-right} y={h-5} textAnchor="end" className="axis">到期汇率：1 CHF = ? USD{hasStrip?'（两张图共用横轴）':''}</text><SvgPointTooltips points={tooltipPoints}/></svg></div>
 <p className="mini">点位说明默认收起；将鼠标移到点位、点按点位，或用 Tab 聚焦后查看。查看说明不会改变情景汇率。</p>
 <div className="legend detailed">{hedged&&<span><i style={{background:'#008274'}}/>对冲后</span>}{bare&&<span><i style={{background:'#8796a3'}}/>不对冲</span>}{deposit&&<span><i style={{background:'#ba8426'}}/>初始本金存款：4.75% 年单利，ACT/365，收益 {money(outcome.benchmark,2)}</span>}</div>
 {unchanged&&<p className="notice">汇率不变参考：目标日 {r.c.end}，S_T = S₀ = <b>{number(r.c.spot,7)} USD/CHF</b>，到期净收益 <b>{money(unchangedPnl,2)}</b>，本金收益率 <b>{percent(unchangedPnl/r.c.equity)}</b>。{!unchangedInView&&'参考点在当前图表范围外，数值仍完整保留。'}这是固定起始汇率参考，独立于当前选中的情景。</p>}
 {(zeroPoints||benchmarkPoints)&&<div className="presentation-crossings">{zeroPoints&&<CrossingDetails title="盈亏平衡 · PNL = 0" color="#b2445a" result={outcome.zero} target={0} r={r} range={range} onSpot={onSpot}/>} {benchmarkPoints&&<CrossingDetails title="追平只存本金 · PNL = PNL_origin" color="#a56b16" result={outcome.deposit} target={outcome.benchmark} r={r} range={range} onSpot={onSpot}/>}<p className="mini">覆盖所有正汇率，图外的交点与相等平台也会列出。PNL_origin = 初始本金 × 4.75% × 实际天数 / 365；比较采用相同持有天数。</p></div>}
 {showScenarios&&<label className="field"><span>拖动查看到期汇率情景（不会改变策略持仓）</span><input aria-label="客户到期汇率情景" type="range" min={range.min} max={range.max} step={(range.max-range.min)/1000} value={Math.max(range.min,Math.min(range.max,spot))} onChange={e=>onSpot(Number(e.target.value))}/></label>}
 {!positionInView&&showScenarios&&<p className="notice">当前情景在图表范围外；情景数值保持不变。</p>}
 <p className="mini">图表范围有限，图中的高低点不代表全域收益上下限。{r.exact?'同日到期的 OTC 行权价标线对应现货赔付的折点。':r.legs.some(l=>l.venue==='CME')?'行权价标线已按目标日模型的期货 / 现货关系映射；提前到期、滚仓和还款日前平仓的结果取决于已设路径、基差与剩余 IV。':'跨期限 OTC 期权按实际期限处理；提前结算路径、剩余期限、IV 与退出成本会影响目标日结果。'}</p>
 {showProbabilities&&<div className="presentation-probabilities"><h3>这些结果有多大可能？先选择观察角度</h3><p className="mini">可以同时勾选多个算法作比较。上图回答“发生这个汇率时赚亏多少”，下图回答“在所选假设下，这个汇率区间有多少权重”；收益大小和发生概率是两件事。</p>
 <div className="chart-legend" role="group" aria-label="客户概率算法显示条件">{models.map(m=><label key={m.id} style={{color:COLORS[m.id]}}><input type="checkbox" checked={selected.includes(m.id)} disabled={historyModel(m.id)&&!history} onChange={e=>setSelected(v=>e.target.checked?[...v,m.id]:v.filter(id=>id!==m.id))}/>{presentationModelGuides[m.id].short}{historyModel(m.id)&&!history?'（需真实历史）':''}</label>)}</div>
 {!models.length&&<p className="notice">管理员尚未开放概率算法。</p>}{models.some(m=>historyModel(m.id))&&!history&&<p className="notice">历史算法需要管理员提供起始日之前的真实现货历史。当前未提供，不生成示例频率。</p>}{!selected.length&&models.length>0&&<p className="mini">勾选一个算法后显示对应区间概率。</p>}
 {distributions.map(m=>{const guide=presentationModelGuides[m.id];if(!m.d||!m.bins)return <div className="notice" key={m.id}><b>{guide.short}</b>：暂不可计算。{m.error}。</div>;const d=m.d,z=outcome.zero?outcomeProbabilities(d,outcome.zero,r.pnl,0):null,b=outcome.deposit?outcomeProbabilities(d,outcome.deposit,r.pnl,outcome.benchmark):null,expectation=expectations.get(m.id);return <article className="threshold-card" key={m.id} style={{borderTop:`3px solid ${COLORS[m.id]}`,marginTop:12}}><h4>{d.kind==='Q'?'Q · 定价参考':'P · 条件估计'}：{guide.short}</h4><p>{guide.why}</p>
 {d.kind==='Q'&&<p className="warning"><b>Q 不是现实胜率。</b>当前仅使用平坦 IV，未实现 Q 期权微笑校准。</p>}
 {expectation?.available?<><div className="presentation-facts presentation-expectation"><div><span>{d.kind==='Q'?'Q 定价测度平均净收益':'模型总预期净收益'}</span><strong>{money(expectation.profit!,2)}</strong></div><div><span>本金期望收益率 · 非年化</span><strong>{percent(expectation.returnOnEquity!)}</strong></div><div><span>预期目标日净资产</span><strong>{money(expectation.endEquity!,2)}</strong></div></div><p className="mini">{expectation.method}；包含完整资金组合的已设权利金、融资、费用、滚仓和图外尾部。{d.kind==='Q'?'这是目标日未贴现的 Q 平均值，不是现实预期收益，也不是当前公允价值。':'这是给定模型与数据的平均结果，不是收益承诺。'}{expectation.standardError!==null&&<> 均值的 Monte Carlo 标准误约 {money(expectation.standardError,2)}（{number(expectation.sampleCount!,0)} 条路径）；只反映有限模拟精度，不含历史样本或模型误差。</>}</p></>:<p className="warning">完整分布预期收益暂不可计算：{expectation?.reason||'缺少可复核的分布信息'}。</p>}
 {z&&b?<><p>{d.kind==='Q'?<>定价分布中，盈利区域权重 <b>{percent(z.better)}</b>，亏损区域权重 <b>{percent(z.worse)}</b>，持平 <b>{percent(z.equal)}</b>。</>:<>按该假设，100 个类似结果中约 <b>{number(z.better*100,0)}</b> 个盈利、<b>{number(z.worse*100,0)}</b> 个亏损、<b>{number(z.equal*100,0)}</b> 个持平。相应权重为 {percent(z.better)} / {percent(z.worse)} / {percent(z.equal)}。</>}</p><p className="mini">{d.kind==='Q'?'定价分布的区域权重':'按该模型的条件估计'}：跑赢美元本金存款 {percent(b.better)} · 相等 {percent(b.equal)} · 跑输 {percent(b.worse)}。{(z.unresolved>0||b.unresolved>0)&&`未决区间分别为 ${percent(z.unresolved)} / ${percent(b.unresolved)}，未计入已确认结果。`}</p></>:<p className="warning">当前自定义公式不支持可靠隔离全域盈亏区域；保留汇率分布，停用组合结果概率。</p>}
 <p className="mini">图外左尾 S &lt; {number(range.min,4)}：<b>{percent(m.bins.left)}</b> · 图内：<b>{percent(m.bins.visible)}</b> · 图外右尾 S &gt; {number(range.max,4)}：<b>{percent(m.bins.right)}</b>。图内柱形未重新归一化为 100%。</p>
 <details><summary>这个算法怎么算，能说明什么？</summary><p className="mini">{guide.method}</p><p className="mini">{d.details}</p><p className="mini">每格是一个汇率区间的概率质量，并非单个汇率点的概率。首格 [a,b]，其余 (a,b]，用分布累计概率之差计算，避免经验样本在相邻格边界重复计数。组合结果按所有全域盈利 / 亏损区域汇总，包含图外尾部；未从图表采样点估算。连续分布单点概率为 0，但 PNL 平台的持平概率可以大于 0。</p>{d.simulation&&z&&<p className="mini">盈利频率的模拟标准误约 {percent(Math.sqrt(z.better*(1-z.better)/d.sampleCount!))}，只反映有限路径的抽样误差，不代表模型误差或未来真实概率的置信区间。</p>}{m.id==='fhs'&&<p className="mini">方法参考：<a className="text-button" href="https://filteredhistoricalsimulation.com/downloads/var28.pdf" target="_blank" rel="noreferrer">Barone-Adesi 等：FHS 原始研究</a>；<a className="text-button" href="https://www.msci.com/documents/10199/5915b101-4206-4ba0-aee2-3449d5c7e95a" target="_blank" rel="noreferrer">RiskMetrics 技术文档，第 5 章：EWMA 与日度 λ=0.94</a>。引用支持方法背景，不代表本工具已经通过这些研究的实证检验。</p>}{m.id==='neutral'&&<p className="mini">方法参考：<a className="text-button" href="https://www.bankofengland.co.uk/-/media/boe/files/ccbs/resources/deriving-option-implied-probability-densities-for-foreign-exchange-markets.pdf" target="_blank" rel="noreferrer">英格兰银行：外汇期权隐含概率技术手册</a>。风险溢价会使定价概率与现实概率不同，完整微笑分布需要额外的市场报价与校准。</p>}</details></article>;})}
 {showPolicyGuide&&<details className="teaching"><summary>政策变化、瑞郎跳升等特殊情景怎么理解？</summary><p className="mini">这些适合单独做压力测试：例如瑞郎突然升值、IV 上升、滚仓价差扩大。没有经过验证的政策发生概率时，不给情景分配百分比，也不把它们混入“胜率”。可用上方汇率滑块查看对应净收益；期内追保与流动性另按工作台条款检查。</p></details>}
 </div>}
 </section>;
}

const intervalText=(lo:number,hi:number)=>lo===0&&hi===Infinity?'所有 S > 0':lo===0?`0 < S ≤ ${number(hi,6)}`:hi===Infinity?`S ≥ ${number(lo,6)}`:`${number(lo,6)} ≤ S ≤ ${number(hi,6)}`;
function CrossingDetails({title,color,result,target,r,range,onSpot}:{title:string;color:string;result:Crossing|null;target:number;r:StrategyResult;range:{min:number;max:number};onSpot:(s:number)=>void}){
 const equal=result?.regions.filter(x=>x.kind==='equal')??[],unresolved=result?.regions.filter(x=>x.kind==='unresolved')??[];
 return <div className="presentation-crossing-card" style={{borderLeft:`3px solid ${color}`,paddingLeft:12,marginTop:12}}><h4 style={{color}}>{title}</h4><p className="mini">对应组合净收益 {money(target,2)}；汇率单位为 USD/CHF。</p>
 {!result?<p className="warning">当前自定义公式不支持可靠求解全域交点，未显示猜测交点。</p>:<>
 {result.roots.length>0&&<ul>{result.roots.map((s,i)=><li key={i}><button type="button" className="text-button" onClick={()=>onSpot(s)}>S = {number(s,7)}</button> · 瑞郎变化 {percent(s/r.c.spot-1)} · 净收益 {money(target,2)}{(s<range.min||s>range.max)&&<span className="pill">图外</span>}</li>)}</ul>}
 {equal.map((x,i)=><p className="mini" key={i}><b>相等平台：{intervalText(x.lo,x.hi)}</b> · 整段净收益均为 {money(target,2)}，没有唯一交点。{(x.lo<range.min||x.hi>range.max)&&<span className="pill">包含图外区间</span>}</p>)}
 {!result.roots.length&&!equal.length&&!unresolved.length&&<p className="mini">所有 S &gt; 0 均无有限相等交点。</p>}
 {unresolved.length>0&&<p className="warning">存在 {unresolved.length} 段未决区域，不能据此断言交点已全部找齐或这些区域处处相等：{unresolved.slice(0,3).map(x=>intervalText(x.lo,x.hi)).join('；')}{unresolved.length>3?'；其余未决区间省略':''}。其未决概率会在各模型中另行列示。</p>}
 </>}</div>;
}
