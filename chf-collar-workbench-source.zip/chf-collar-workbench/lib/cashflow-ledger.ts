import type {StrategyResult} from './strategy';
import {year} from './finance';

export type CashflowStep={step:number;date:string;phase:string;action:string;usd:number;chf:number;usdBalance:number;chfBalance:number;note:string};

/** Cash-account ledger. Transfers into investments/collateral are not expenses. */
export function cashflowLedger(r:StrategyResult,s=r.c.scenario):CashflowStep[]{
 const c=r.c, rows:Omit<CashflowStep,'step'|'usdBalance'|'chfBalance'>[]=[];
 const add=(date:string,phase:string,action:string,usd=0,chf=0,note='')=>rows.push({date,phase,action,usd,chf,note});
 add(c.start,'期初','注入自有美元本金',c.equity);
 if(c.mode==='loan'){
  add(c.start,'期初','借入瑞郎本金',0,c.loan,'实际债务币种为 CHF；美元金额是换汇前等值。');
  add(c.start,'期初','卖出瑞郎，换入美元',c.loan*c.spot,-c.loan,`1 CHF = ${c.spot} USD；换汇费另列。`);
 }else{
  add(c.start,'期初','美元换入瑞郎',-c.equity,r.a0);
  add(c.start,'期初','存入瑞郎定期存款',0,-r.a0,'资金转入存款资产，不是费用。');
 }
 for(const l of r.legs){
  add(c.start,'期初',`${l.id} ${l.side==='buy'?'买入':'卖出'} ${l.type.toUpperCase()} 权利金`,-l.premium,0,`${l.h} CHF；K=${l.strike}；${l.venue}；到期 ${l.expiry}`);
  add(c.start,'期初',`${l.id} 期权开仓费`,-l.fee);
 }
 add(c.start,'期初','支付即期换汇费',-r.feeFX);
 add(c.start,'期初','划入期权保证金账户',-c.margin,0,'可返还的资金占用；不作为损失。');
 add(c.start,'期初','划入现金储备账户',-c.reserve,0,'独立储备账户；目标日归集。');
 add(c.start,'期初',r.deposit>=0?'存入美元投资账户':'借入补充美元融资',-r.deposit,0,r.deposit>=0?'美元存款本金。':'初始资金不足；后续需要偿付美元融资本息。');
 const early=r.legs.filter(l=>l.expiry<c.end).sort((a,b)=>a.expiry.localeCompare(b.expiry));
 for(const l of early){
  const raw=r.legValue(l,s,l.tau);
  add(l.expiry,'期间',`${l.id} 提前于目标日到期结算（条件）`,raw,0,`假定该日期 fixing 也等于情景 ${s}；真实路径未知。${l.venue==='CME'?'CME 期货处置后的经济等值，非实际逐日盯市。':''}`);
  add(l.expiry,'期间',`${l.id} 结算款转入滚动现金账户`,-raw,0,'正数收益存放；负数支出按相同投资增长因子计机会成本，与组合模型一致。');
 }
 add(c.end,'目标日',r.deposit>=0?'美元存款本金到账':'偿付补充美元融资本金',r.deposit);
 add(c.end,'目标日',r.deposit>=0?'美元投资利息到账':'支付补充美元融资利息',r.interest);
 add(c.end,'目标日','释放期权保证金本金',c.margin);
 add(c.end,'目标日','保证金利息到账',r.collInterest);
 add(c.end,'目标日','归集现金储备',c.reserve);
 for(const l of r.legs){
  const value=r.legValue(l,s,r.t);
  if(l.expiry<c.end){
   const raw=r.legValue(l,s,l.tau);
   add(c.end,'目标日',`${l.id} 滚动现金本金归集`,raw);
   add(c.end,'目标日',`${l.id} 滚动期间利息或机会成本`,value-raw,0,`期间 ${year(l.expiry,c.end)*365} 天；条件现金流。`);
  }else add(c.end,'目标日',`${l.id} ${l.expiry>c.end?'期权平仓模型估值':'期权到期结算'}`,value,0,l.expiry>c.end?'尚未到期，按模型市值退出；不是保证赔付。':l.venue==='CME'?'CME 期货结算的经济等值；尚有期现基差与交割操作。':'按所选情景汇率计算有符号现金赔付。');
 }
 if(c.mode==='loan'){
  add(c.end,'目标日','买入应还瑞郎本息',-r.n*s,r.n,`目标日情景：1 CHF = ${s} USD。`);
  add(c.end,'目标日','归还瑞郎借款本金',0,-c.loan);
  add(c.end,'目标日','支付瑞郎借款利息',0,-(r.n-c.loan));
 }else{
  add(c.end,'目标日','瑞郎存款本金及利息到账',0,r.n);
  add(c.end,'目标日','瑞郎换回美元',r.n*s,-r.n);
 }
 add(c.end,'目标日','支付最终结算费用',-c.exitFee);
 let usdBalance=0,chfBalance=0;
 return rows.map((row,i)=>({...row,step:i+1,usdBalance:usdBalance+=row.usd,chfBalance:chfBalance+=row.chf}));
}
