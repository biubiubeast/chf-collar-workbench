# CHF 领口对冲工作台

私有网站：[打开工作台](https://chf-collar-lab.gpt4both.chatgpt.site)。使用获授权的 ChatGPT 账号登录。

源码：[biubiubeast/chf-collar-workbench](https://github.com/biubiubeast/chf-collar-workbench)。本仓库包含网站前后端、市场参考快照、使用手册、锁定依赖和测试；网站继续运行在 Sites。

## 本地运行

需要 Node.js 22.13+（建议 Node 24）和 pnpm 11.25.0。

```sh
git clone https://github.com/biubiubeast/chf-collar-workbench.git
cd chf-collar-workbench
npm install -g pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm dev
```

打开终端打印的地址，通常是 http://127.0.0.1:5173/。无需 API 密钥或数据库。方案和自定义公式保存在当前浏览器，不会上传到 GitHub。

```sh
pnpm test
pnpm typecheck
pnpm build
pnpm start
```

start 使用构建后的 Worker 做本地预览。dist/client 和 dist/server 是可重新生成的构建产物。GitHub Actions 执行测试和构建，并保留网站构建包。

## V3 本金、杠杆和 Excel

1. 在 CHF 负债模式输入自有美元本金。
2. 选择借款倍数自动计算，或手动输入 CHF 借款。可选不借款、常用 1–4 倍或非负自定义倍数。
3. 设置即期、年利率及起止日期。刷新市场数据更新 ECB 日度参考和 CME 参考链；它们不是实时可成交报价。
4. 查看美元借款等值、实际 CHF 借款、到期利息及本息。
5. 如需调整已有期权数量，点击“将启用腿数量同步到到期本息”，再核对覆盖率、日期和执行价。
6. 选择目标日汇率情景，点击“下载 Excel”。浏览器未自动下载时，点击“保存刚生成的 Excel 文件”。

S 是每 1 CHF 的美元价格。借款倍数 = 借款美元等值 / 自有本金；4 倍借款代表总资金 5 倍。

```text
借款美元等值 = 自有本金 × 借款倍数
CHF 本金 = 借款美元等值 / S
默认 CHF 本息 = CHF 本金 × (1 + 年利率 × 实际天数 / 365)
```

借入的实际币种是 CHF，美元是换汇前毛等值，换汇费另计。自定义 growth 公式也作用于到期本息。已实际提款的 CHF 借款应使用手动金额模式固定数量，避免更新汇率重新改变借款假设。调整资金不会静默改动期权腿。

Excel 是真实 .xlsx，包含“现金流步骤”和“参数与期权”。按日期和顺序列出每腿权利金、费用、投资、保证金和储备、期权结算及还款，显示 USD/CHF 变化、双币累计余额和净资产核对。日期和金额为原生类型，余额使用公式。它保存导出时的方案；修改策略或市场参数后应返回网站重算并重新导出。

## 源码导览

| 文件 / 目录 | 用途 |
| --- | --- |
| app/page.tsx | 主工作台、方案状态和下载入口 |
| components/funding-panel.tsx | 杠杆输入和融资摘要 |
| lib/funding.ts | 本金与借款换算 |
| lib/strategy.ts | 多腿期权、损益、资产负债表、压力情景 |
| lib/cashflow-ledger.ts | 按日期排列且可勾稽的现金流 |
| lib/excel-export.ts | 浏览器 ExcelJS 导出，不向外部发送方案参数 |
| lib/formulas.ts、app/formulas | 受限数学公式语言与公式管理 |
| app/api/market、app/api/spot | CME / ECB 公共参考数据适配器 |
| app/api-manager | 数据源与刷新设置 |
| app/legacy | 原版领口与历史 IV 实验室 |
| public/CHF-Collar-Lab-V2-Manual.docx | 原 V2 手册；V3 新功能见本 README |
| tests | 金融恒等式、数据、融资和 Excel 验证 |

## 数据和模型边界

保存快照带日期，缺失的 BBO、L2、真实历史 IV 不伪造。CME 刷新失败时只对同期限返回已标记的快照，其他期限报错。ECB 使用同日 EUR/USD 和 EUR/CHF 交叉计算。

默认资金单利 ACT/365，期权为欧式 Black 估价。OTC 精确期限仍是模型，CME 存在期现基差、行权后的期货处置和银行换汇操作。早到期期权假定 fixing 等于情景值并滚动现金至目标日；晚到期期权按目标日市值退出。Excel 标记这些条件，不冒充真实成交流水。银行和期权卖方追保仍可能在持有期发生。

## 发布和 Codex 后续开发

在 Codex 打开本目录，先读 AGENTS.md。继续使用 .openai/hosting.json 中的原 Site：appgprj_6ac26409050481919f506a1082bb74e7，保持私有。通过 Sites 技能同步源码、检查构建、保存版本并部署。GitHub 提交不会自动发布 Sites；Actions 构建产物用于下载和核验。

不要提交令牌、.env、浏览器中的客户方案或本地运行状态。
