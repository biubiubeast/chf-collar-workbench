# CHF 领口对冲工作台

私有网站：[打开工作台](https://chf-collar-lab.gpt4both.chatgpt.site)。使用获授权的 ChatGPT 账号登录。

源码：[biubiubeast/chf-collar-workbench](https://github.com/biubiubeast/chf-collar-workbench)。本仓库包含网站前后端、市场参考快照、使用手册、锁定依赖和测试；网站继续运行在 Sites。

## 本地运行

需要 Node.js 22.13+（建议 Node 24）和 pnpm 11.25.0。

```sh
git clone https://github.com/biubiubeast/chf-collar-workbench.git
cd chf-collar-workbench
npm install -g pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm dev
```

打开终端打印的地址，通常是 http://127.0.0.1:5173/。无需 API 密钥或数据库。方案和自定义公式保存在当前浏览器，不会上传到 GitHub。

```sh
pnpm test
pnpm typecheck
pnpm build
pnpm start
```

start 使用构建后的 Worker 做本地预览。dist/client 和 dist/server 是可重新生成的构建产物。GitHub Actions 执行测试和构建，并保留网站构建包。

## V3 本金、杠杆和 Excel

1. 在 CHF 负债模式输入自有美元本金。
2. 选择借款倍数自动计算，或手动输入 CHF 借款。可选不借款、常用 1–4 倍或非负自定义倍数。
3. 设置即期、年利率及起止日期。刷新市场数据更新 ECB 日度参考和 CME 参考链；它们不是实时可成交报价。
4. 查看美元借款等值、实际 CHF 借款、到期利息及本息。
5. 如需调整已有期权数量，点击“将启用腿数量同步到到期本息”，再核对覆盖率、日期和执行价。
6. 选择目标日汇率情景，点击“下载 Excel”。浏览器未自动下载时，点击“保存刚生成的 Excel 文件”。

S 是每 1 CHF 的美元价格。借款倍数 = 借款美元等值 / 自有本金；4 倍借款代表总资金 5 倍。

```text
借款美元等值 = 自有本金 × 借款倍数
CHF 本金 = 借款美元等值 / S
默认 CHF 本息 = CHF 本金 × (1 + 年利率 × 实际天数 / 365)
```

借入的实际币种是 CHF，美元是换汇前毛等值，换汇费另计。自定义 growth 公式也作用于到期本息。已实际提款的 CHF 借款应使用手动金额模式固定数量，避免更新汇率重新改变借款假设。调整资金不会静默改动期权腿。

Excel 是真实 .xlsx，包含“现金流步骤”和“参数与期权”。按日期和顺序列出每腿权利金、费用、投资、保证金和储备、期权结算及还款，显示 USD/CHF 变化、双币累计余额和净资产核对。日期和金额为原生类型，余额使用公式。它保存导出时的方案；修改策略或市场参数后应返回网站重算并重新导出。

## 源码导览

| 文件 / 目录 | 用途 |
| --- | --- |
| app/page.tsx | 主工作台、方案状态和下载入口 |
| components/funding-panel.tsx | 杠杆输入和融资摘要 |
| lib/funding.ts | 本金与借款换算 |
| lib/strategy.ts | 多腿期权、损益、资产负债表、压力情景 |
| lib/cashflow-ledger.ts | 按日期排列且可勾稽的现金流 |
| lib/excel-export.ts | 浏览器 ExcelJS 导出，不向外部发送方案参数 |
| lib/formulas.ts、app/formulas | 受限数学公式语言与公式管理 |
| app/api/market、app/api/spot | CME / ECB 公共参考数据适配器 |
| app/api-manager | 数据源与刷新设置 |
| app/legacy | 原版领口与历史 IV 实验室 |
| public/CHF-Collar-Lab-V2-Manual.docx | 原 V2 手册；V3 新功能见本 README |
| tests | 金融恒等式、数据、融资和 Excel 验证 |

## 数据和模型边界

保存快照带日期，缺失的 BBO、L2、真实历史 IV 不伪造。CME 刷新失败时只对同期限返回已标记的快照，其他期限报错。ECB 使用同日 EUR/USD 和 EUR/CHF 交叉计算。

默认资金单利 ACT/365，期权为欧式 Black 估价。OTC 精确期限仍是模型，CME 存在期现基差、行权后的期货处置和银行换汇操作。早到期期权假定 fixing 等于情景值并滚动现金至目标日；晚到期期权按目标日市值退出。Excel 标记这些条件，不冒充真实成交流水。银行和期权卖方追保仍可能在持有期发生。

## 发布和 Codex 后续开发

在 Codex 打开本目录，先读 AGENTS.md。继续使用 .openai/hosting.json 中的原 Site：appgprj_6ac26409050481919f506a1082bb74e7，保持私有。通过 Sites 技能同步源码、检查构建、保存版本并部署。GitHub 提交不会自动发布 Sites；Actions 构建产物用于下载和核验。

不要提交令牌、.env、浏览器中的客户方案或本地运行状态。

## V3.1 对冲归因与 CME 全域边界

本金汇兑损益继续使用 `L × (S₀ − S)`。这是未对冲分项；期权赔付单独计入，新增对冲后本息与汇兑小计和执行价上下的对照表。足量、同日 OTC Call 在 S≥K 后锁定 `L×S₀−N×K`，仍保留执行价差额、利息和权利金，最低收益不必为零。新增“按当前本息足额买 Call”，CME 向上取整；跨期限的单买 Call 可显式按当前模型条件补足尾部。

`lib/global-bounds.ts` 对全部 S≥0 求边界：已到期用归一化折点 K/a 和解析尾部；未到期用 Black 凸性弦线误差包络及无穷远 Put 残值控制。每个有限边界携带估计极值、USD 误差、收敛状态与方法。真正的无限风险不改成一个图表区间内的有限数。

CME 按各腿对应期货 F₀、过去持有成本、基差压力及提前到期路径映射到 F_u；不再在到期时直接用现货 S 代替期货 fixing，也不在未到期时永久保留起初全部期货升水。可用参考价反推每腿 Black IV，无效时明确回退输入 IV。API 对齐期货和期权报价日；不匹配时采用披露 4% 折现假设的跨执行价平价中位数，禁止混合月份。

新增假设：`cmeBasisBp` 默认 0 bp；`earlySpotRatio` 默认 1。这些是条件，不是实盘基差或路径保证。公式管理 `/formulas#hedge-logic` 展示完整定义、算法、官方来源、当前方案和 CME 足额 Call 对照。Excel 保存相同假设、IV 和边界。

回归审计：`tests/bounds.test.mjs`；数值审计输出到被忽略的 `outputs/verification/bounds-audit.json`。

## V3.2 代表案例

图表上方的案例区默认提供起点汇率 10%、100%、300% 三个有限压力例子，支持增删（1–20 例）、改名、修改汇率、切换目标偿付日或期前估值。案例自动保存在浏览器 chf-expiry-cases-v1；首次读取旧方案以原 scenario 填入中间案例。默认高低数值不代表数学极限，亦不随后续现价刷新覆写用户编辑。

每条启用 CME/OTC 腿显示实际 CHF 数量、执行价、到期日、成交价、权利金、开仓费、各例价值与净收益。净收益减有符号权利金与开仓费；融资、换汇等在组合归因中计入。图表点击/拖动修改当前选定案例。

Excel 保留原资金参数与操作表，新增案例总览及每例独立工作表，保存所有例子的逐腿成本、收益分解和偿付日现金流。期前例子单独标注市值，不虚构已经发生的清偿流水。非法输入阻止导出并指出具体案例。方案 JSON 也包含案例与当前选择。
